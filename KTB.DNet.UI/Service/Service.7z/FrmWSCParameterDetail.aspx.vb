﻿#Region "DNet"
Imports KTB.DNet.Utility
Imports KTB.DNet.Domain
Imports KTB.DNet.BusinessFacade
Imports KTB.DNet.BusinessFacade.General
Imports KTB.DNet.BusinessFacade.FinishUnit
Imports KTB.DNet.BusinessFacade.Service
Imports KTB.DNet.BusinessFacade.SparePart
Imports KTB.DNet.Domain.Search
Imports KTB.DNet.Security
#End Region

#Region "System"
Imports System.Text
Imports System.IO
Imports System.Linq
#End Region

Public Class FrmWSCParameterDetail
    Inherits System.Web.UI.Page

#Region "Private Variable"
    Private sessHelper As SessionHelper = New SessionHelper
    Private m_bFormPrivilege As Boolean = False
    Private m_bCreatePrivilege As Boolean = False
    Private m_bUpdatePrivilege As Boolean = False
    Private m_bActivatePrivilege As Boolean = False
    Private backURL As String = String.Empty
    Private wscHeaderID As Integer = 0
    Private Mode As String = String.Empty
#End Region

#Region "Check Privilege"
    Private Sub ActivateParameterPrivilege()
        m_bFormPrivilege = SecurityProvider.Authorize(Context.User, SR.WSCParameterView_Privilege)
        m_bCreatePrivilege = SecurityProvider.Authorize(Context.User, SR.WSCParameterCreate_Privilege)
        m_bUpdatePrivilege = SecurityProvider.Authorize(Context.User, SR.WSCParameterUpdate_Privilege)
        m_bActivatePrivilege = SecurityProvider.Authorize(Context.User, SR.WSCParameterActivate_Privilege)

        If Not m_bFormPrivilege _
            AndAlso Not m_bCreatePrivilege _
            AndAlso Not m_bActivatePrivilege _
            AndAlso Not m_bUpdatePrivilege Then
            Server.Transfer("../FrmAccessDenied.aspx?modulName=Waranty Service Claim - Input Parameter WSC")
        End If

        If m_bCreatePrivilege Then
            btnSimpan.Visible = True
            btnBatal.Visible = True
        Else
            btnSimpan.Visible = False
            btnBatal.Visible = False
        End If

        If m_bActivatePrivilege Then
            sessHelper.SetSession("ActivateParameter", True)
        Else
            sessHelper.SetSession("ActivateParameter", False)
        End If

        If m_bUpdatePrivilege Then
            sessHelper.SetSession("UpdateParameter", True)
        Else
            sessHelper.SetSession("UpdateParameter", False)
        End If
    End Sub

    Private Sub SetControlPrivilege()
        If Mode = "View" Then
            btnSimpan.Enabled = False
            dtgWscParam.Enabled = False
            dtgWscParam.ShowFooter = False
        ElseIf Mode = "Detail" Then
            btnSimpan.Enabled = True
            dtgWscParam.Enabled = True
            dtgWscParam.ShowFooter = True
        End If
        btnBatal.Visible = True
        If m_bCreatePrivilege OrElse m_bUpdatePrivilege Then
            btnSimpan.Visible = True
        ElseIf m_bFormPrivilege OrElse m_bActivatePrivilege Then
            btnSimpan.Visible = False
        End If
    End Sub
#End Region

#Region "Custom Method"
    Private Sub BindParameter(ByVal ddlItem As DropDownList)
        ddlItem.Items.Clear()
        Dim enumParameter As ArrayList = New EnumWSCParamParameter().RetrieveWSCParameterLI()
        For Each item As ListItem In enumParameter
            If Not IsNothing(ddlItem) Then
                ddlItem.Items.Add(item)
            End If
        Next
    End Sub

    Private Sub BindOperator(ByVal ddlItem As DropDownList)
        ddlItem.Items.Clear()
        Dim enumParameter As ArrayList = New EnumWSCParamParameter().RetrieveWSCOperatorLI()
        Dim dgSource As ArrayList = New ArrayList
        For Each item As ListItem In enumParameter
            If Not IsNothing(ddlItem) Then
                ddlItem.Items.Add(item)
            End If
        Next
    End Sub

    Private Sub BindDataGrid(ByVal p1 As Integer, ByVal index As Integer)
        Dim totalRow As Integer = 0
        Dim arlDGrid As ArrayList = New ArrayList
        Dim criteria As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(WSCParameterDetail), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        criteria.opAnd(New Criteria(GetType(WSCParameterDetail), "WSCParameterHeader.ID", MatchType.Exact, p1))
        arlDGrid = New WSCParameterDetailFacade(User).RetrieveByCriteria(criteria, index + 1, dtgWscParam.PageSize, totalRow)
        If p1 = -1 AndAlso index = -1 Then
            arlDGrid = CType(sessHelper.GetSession("ParamGrid"), ArrayList)
        End If

        sessHelper.SetSession("ParamGrid", CType(arlDGrid, ArrayList))
        dtgWscParam.DataSource = arlDGrid
        dtgWscParam.DataBind()
    End Sub

    Private Sub Initialize()
        sessHelper.SetSession("ParamGrid", New ArrayList)
        If Mode <> "" AndAlso wscHeaderID <> 0 Then
            Dim arlWSCVehicle As ArrayList = New ArrayList
            Dim oWSCHeader As WSCParameterHeader = New WSCParameterHeaderFacade(User).Retrieve(wscHeaderID)
            Dim criteria As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(WSCParameterVehicle), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
            criteria.opAnd(New Criteria(GetType(WSCParameterVehicle), "WSCParameterHeader.ID", MatchType.Exact, wscHeaderID))
            arlWSCVehicle = New WSCParameterVehicleFacade(User).Retrieve(criteria)

            lblClaimType.Text = oWSCHeader.ClaimType.ToString
            lblDescription.Text = oWSCHeader.Description.ToString
            lblStatus.Text = New EnumWSCParamStatus().RetrieveStatusMode(oWSCHeader.Status).DescStatus
            getCategoryFromType(wscHeaderID)

            For Each oWscVehicle As WSCParameterVehicle In arlWSCVehicle
                lboxVehicleType.Items.Add(oWscVehicle.VechileType.VechileTypeCode)
            Next
        End If
        BindDataGrid(wscHeaderID, 0)
        SetControlPrivilege()
        ViewState("currSortColumn") = "ID"
        ViewState("currSortDirection") = Sort.SortDirection.ASC

    End Sub

    Private Sub SessionInit()
        If Not IsNothing(Request.QueryString("Mode").ToString) Then
            Mode = Request.QueryString("Mode").ToString
        End If
        If Not IsNothing(sessHelper.GetSession("vsWSCParameterID")) Then
            wscHeaderID = sessHelper.GetSession("vsWSCParameterID")
        End If
    End Sub

    Private Sub getCategoryFromType(ByVal ParamHeadID As Integer)
        Dim arlParamVehicle As ArrayList = New ArrayList
        Dim criteria As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(WSCParameterVehicle), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        criteria.opAnd(New Criteria(GetType(WSCParameterVehicle), "WSCParameterHeader.ID", MatchType.Exact, ParamHeadID))
        arlParamVehicle = New WSCParameterVehicleFacade(User).Retrieve(criteria)
        For Each item As WSCParameterVehicle In arlParamVehicle
            insertCategoryListBox(item.VechileType.Description.Split(" "))
        Next
    End Sub

    Private Sub insertCategoryListBox(ByVal p1 As String())
        For Each item As String In p1
            If item.ToUpper = "TRITON".ToUpper _
                OrElse item.ToUpper = "LANCER".ToUpper _
                OrElse item.ToUpper = "GRANDIS".ToUpper _
                OrElse item.ToUpper = "MAVEN".ToUpper _
                OrElse item.ToUpper = "PAJERO".ToUpper _
                OrElse item.ToUpper = "OUTLANDER".ToUpper _
                OrElse item.ToUpper = "MIRAGE".ToUpper _
                OrElse item.ToUpper = "DELICA".ToUpper _
                OrElse item.ToUpper = "XPANDER".ToUpper _
                OrElse item.ToUpper = "EXPANDER".ToUpper _
                OrElse item.ToUpper = "T120SS".ToUpper _
                OrElse item.ToUpper = "L300".ToUpper Then
                Dim li As ListItem = New ListItem(item.ToUpper)
                If Not lboxCategory.Items.Contains(li) Then
                    lboxCategory.Items.Add(li)
                End If
            End If
        Next
    End Sub

    Private Sub insertSession(ByVal Prmtr As String, ByVal Oprt As String, ByVal Val As String, Optional ByVal ReasonCode As String = "")
        Dim arlWSCParamDetail As ArrayList = CType(sessHelper.GetSession("ParamGrid"), ArrayList)
        Dim oWSCParamDetail As WSCParameterDetail = New WSCParameterDetail
        oWSCParamDetail.Kind = Prmtr
        oWSCParamDetail.Operators = Oprt
        oWSCParamDetail.Value = Val
        oWSCParamDetail.ReasonCode = ReasonCode.Trim
        arlWSCParamDetail.Add(oWSCParamDetail)
        sessHelper.SetSession("ParamGrid", arlWSCParamDetail)
    End Sub
#End Region

#Region "Event Handler"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ActivateParameterPrivilege()
        SessionInit()
        If Not IsPostBack Then
            Initialize()
        End If
    End Sub

    Protected Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        Response.Redirect(sessHelper.GetSession("backURL").ToString)
    End Sub

    Protected Sub dtgWscParam_ItemDataBound(sender As Object, e As DataGridItemEventArgs) Handles dtgWscParam.ItemDataBound
        Dim ddlParameter As Label
        Dim ddlOperator As Label
        Dim lblValue As Label
        Dim lblReasonCode As Label
        Dim ddlParameterF As DropDownList
        Dim ddlOperatorF As DropDownList
        Dim txtValueF As TextBox
        Dim txtReasonCodeF As TextBox
        Dim index = e.Item.ItemIndex
        Dim oWSCParamDetail As WSCParameterDetail = New WSCParameterDetail
        Dim arlWSCParamDetail As ArrayList = CType(sessHelper.GetSession("ParamGrid"), ArrayList)
        Dim ItemType As ListItemType = CType(e.Item.ItemType, ListItemType)

        If ItemType = ListItemType.Item OrElse ItemType = ListItemType.AlternatingItem Then
            ddlParameter = CType(e.Item.FindControl("lblParameter"), Label)
            ddlOperator = CType(e.Item.FindControl("lblOperator"), Label)
            lblValue = CType(e.Item.FindControl("lblValue"), Label)
            lblReasonCode = CType(e.Item.FindControl("lblReasonCode"), Label)
            Dim lblNo As Label = CType(e.Item.FindControl("lblNo"), Label)
            oWSCParamDetail = arlWSCParamDetail(index)
            ddlParameter.Text = New EnumWSCParamParameter().RetrieveWSCParameter(oWSCParamDetail.Kind)
            ddlOperator.Text = New EnumWSCParamParameter().RetrieveWSCParamOperator(oWSCParamDetail.Operators)
            lblValue.Text = oWSCParamDetail.Value
            lblReasonCode.Text = oWSCParamDetail.ReasonCode
            lblNo.Text = index + 1
        ElseIf ItemType = ListItemType.Footer Then
            ddlParameterF = CType(e.Item.FindControl("ddlParameterFooter"), DropDownList)
            ddlOperatorF = CType(e.Item.FindControl("ddlOperatorFooter"), DropDownList)
            txtValueF = CType(e.Item.FindControl("txtValueFooter"), TextBox)
            txtReasonCodeF = CType(e.Item.FindControl("txtReasonCodeFooter"), TextBox)
            BindParameter(ddlParameterF)
            BindOperator(ddlOperatorF)
            ddlParameterF.ClearSelection()
            ddlOperatorF.ClearSelection()
            txtValueF.Text = ""
            txtReasonCodeF.Text = ""
        End If
    End Sub

    Protected Sub dtgWscParam_ItemCommand(source As Object, e As DataGridCommandEventArgs) Handles dtgWscParam.ItemCommand
        Dim _arParamGrid As ArrayList = CType(sessHelper.GetSession("ParamGrid"), ArrayList)

        Dim ddlParameterF As DropDownList
        Dim ddlOperatorF As DropDownList
        Dim txtValueF As TextBox
        Dim txtReasonCodeF As TextBox
        Dim strValue As String

        Select Case e.CommandName
            Case "Add" 'Insert New item to datagrid
                ddlOperatorF = CType(e.Item.FindControl("ddlOperatorFooter"), DropDownList)
                ddlParameterF = CType(e.Item.FindControl("ddlParameterFooter"), DropDownList)
                txtReasonCodeF = CType(e.Item.FindControl("txtReasonCodeFooter"), TextBox)
                If ddlParameterF.SelectedValue = 4 OrElse ddlParameterF.SelectedValue = 6 OrElse ddlParameterF.SelectedValue = 7 OrElse ddlParameterF.SelectedValue = 8 Then
                    txtValueF = CType(e.Item.FindControl("txtValueFooterNum"), TextBox)
                    strValue = txtValueF.Text
                ElseIf ddlParameterF.SelectedValue = 1 OrElse ddlParameterF.SelectedValue = 2 OrElse ddlParameterF.SelectedValue = 3 Then
                    strValue = CType(e.Item.FindControl("icValueFooter"), KTB.DNet.WebCC.IntiCalendar).Value
                Else
                    txtValueF = CType(e.Item.FindControl("txtValueFooter"), TextBox)
                    strValue = txtValueF.Text
                End If
                'Dim _nResult As Integer = ValidateInput(ddlParameterF.SelectedValue, ddlOperatorF.SelectedValue)
                'If _nResult = 0 Then
                If ddlOperatorF.SelectedIndex > 0 AndAlso ddlParameterF.SelectedIndex > 0 AndAlso strValue.Trim.Length > 0 Then
                    If ddlParameterF.SelectedIndex = 6 Then
                        If lblClaimType.Text.Trim.ToUpper = "Z2" Then
                            If Not Char.IsLetter(txtValueF.Text) OrElse txtValueF.Text = "XEE999" Then
                                insertSession(ddlParameterF.SelectedValue, ddlOperatorF.SelectedValue, strValue, txtReasonCodeF.Text)
                            Else
                                MessageBox.Show("Untuk Type Claim Z2, \n Kode Posisi hanya boleh yang berawalan Angka")
                            End If
                        ElseIf lblClaimType.Text.Trim.ToUpper = "Z4" Then
                            If Char.IsLetter(txtValueF.Text) Then
                                insertSession(ddlParameterF.SelectedValue, ddlOperatorF.SelectedValue, strValue, txtReasonCodeF.Text)
                            Else
                                MessageBox.Show("Untuk Type Claim Z4, \n Kode Posisi hanya boleh yang berawalan Huruf")
                            End If
                        Else
                            insertSession(ddlParameterF.SelectedValue, ddlOperatorF.SelectedValue, strValue, txtReasonCodeF.Text)
                        End If
                    Else
                        insertSession(ddlParameterF.SelectedValue, ddlOperatorF.SelectedValue, strValue, txtReasonCodeF.Text)
                    End If
                ElseIf ddlOperatorF.SelectedIndex = 0 AndAlso ddlParameterF.SelectedIndex = 0 AndAlso strValue.Trim.Length = 0 Then
                    MessageBox.Show("Data masih kosong")
                ElseIf ddlOperatorF.SelectedIndex = 0 Then
                    MessageBox.Show("Silahkan pilih Operator terlebih dahulu")
                ElseIf ddlParameterF.SelectedIndex = 0 Then
                    MessageBox.Show("Silahkan pilih Parameter terlebih dahulu")
                ElseIf strValue.Trim.Length = 0 Then
                    MessageBox.Show("Silahkan isi value terlebih dahulu")
                End If
                'Else
                'MessageBox.Show(SR.SaveFail)
                'End If

            Case "Delete" 'Delete this datagrid item
                sessHelper.RemoveSession("ParamGrid")
                sessHelper.SetSession("ParamGrid", New ArrayList)
                For index As Integer = 0 To _arParamGrid.Count - 1
                    Select Case e.Item.ItemType
                        Case ListItemType.Item, ListItemType.AlternatingItem
                            Dim ddlParameter As Label = CType(e.Item.FindControl("lblParameter"), Label)
                            Dim ddlOperator As Label = CType(e.Item.FindControl("lblOperator"), Label)
                            Dim lblValue As Label = CType(e.Item.FindControl("lblValue"), Label)
                            Dim lblReasonCode As Label = CType(e.Item.FindControl("lblReasonCode"), Label)
                            Dim parameter As Integer
                            Dim op As Integer
                            For Each item As ListItem In New EnumWSCParamParameter().RetrieveWSCParameterLI
                                If item.Text.ToUpper = ddlParameter.Text.ToUpper Then
                                    parameter = CType(item.Value, Integer)
                                End If
                            Next
                            For Each item As ListItem In New EnumWSCParamParameter().RetrieveWSCOperatorLI
                                If item.Text.ToUpper = ddlOperator.Text.ToUpper Then
                                    op = CType(item.Value, Integer)
                                End If
                            Next
                            insertSession(parameter, op, lblValue.Text, lblReasonCode.Text)
                        Case ListItemType.Footer
                            ddlOperatorF = CType(e.Item.FindControl("ddlOperatorFooter"), DropDownList)
                            ddlParameterF = CType(e.Item.FindControl("ddlParameterFooter"), DropDownList)
                            txtReasonCodeF = CType(e.Item.FindControl("txtReasonCodeFooter"), TextBox)
                            '(selectedParameterValue == "4" || selectedParameterValue == "6" || selectedParameterValue == "7" || selectedParameterValue == "8") 
                            If ddlParameterF.SelectedValue = 4 OrElse ddlParameterF.SelectedValue = 6 OrElse ddlParameterF.SelectedValue = 7 OrElse ddlParameterF.SelectedValue = 8 Then
                                txtValueF = CType(e.Item.FindControl("txtValueFooterNum"), TextBox)
                            Else
                                txtValueF = CType(e.Item.FindControl("txtValueFooter"), TextBox)
                            End If
                            insertSession(ddlParameterF.SelectedValue, ddlOperatorF.SelectedValue, txtValueF.Text, txtReasonCodeF.Text)
                    End Select
                Next
                _arParamGrid.RemoveAt(e.Item.ItemIndex)
                sessHelper.SetSession("ParamGrid", CType(_arParamGrid, ArrayList))
        End Select
        BindDataGrid(-1, -1)
    End Sub

    Protected Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        Dim oWSCDetail As WSCParameterDetail
        Dim oWSCDetailF As New WSCParameterDetailFacade(User)
        Dim arrParamGrid As ArrayList = CType(sessHelper.GetSession("ParamGrid"), ArrayList)
        If arrParamGrid.Count > 0 Then
            reFlush(wscHeaderID)
            Dim nResult = -1
            For Each item As WSCParameterDetail In arrParamGrid
                oWSCDetail = New WSCParameterDetail
                Dim oWSCHeader As New WSCParameterHeader
                oWSCHeader.ID = wscHeaderID
                oWSCDetail.WSCParameterHeader = oWSCHeader
                oWSCDetail.Kind = item.Kind
                oWSCDetail.Operators = item.Operators
                oWSCDetail.Value = item.Value
                oWSCDetail.ReasonCode = item.ReasonCode
                nResult = oWSCDetailF.Insert(oWSCDetail)
            Next

            If nResult > -1 Then
                MessageBox.Show(SR.SaveSuccess)
                Server.Transfer("FrmWSCParameterHeader.aspx")
            Else
                MessageBox.Show(SR.SaveFail)
            End If
        Else
            'MessageBox.Show("Parameter tidak boleh Kosong")
            Try
                Dim deCount As Integer = oWSCDetailF.ScalarDetail(wscHeaderID)
                If deCount > 0 Then
                    reFlush(wscHeaderID)
                End If
            Catch
            End Try
        End If
    End Sub

    Private Sub reFlush(ByVal HeaderID As String)
        Dim crit As New CriteriaComposite(New Criteria(GetType(WSCParameterDetail), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        crit.opAnd(New Criteria(GetType(WSCParameterDetail), "WSCParameterHeader.ID", MatchType.Exact, HeaderID))
        Dim arrWscPaDe As ArrayList = New WSCParameterDetailFacade(User).Retrieve(crit)
        For Each item As WSCParameterDetail In arrWscPaDe
            Dim oWscParamHeader As WSCParameterHeader = New WSCParameterHeaderFacade(User).Retrieve(CType(HeaderID, Integer))
            item.WSCParameterHeader = oWscParamHeader
            Dim del As New WSCParameterDetailFacade(User)
            del.Delete(item)
        Next
    End Sub

#End Region

End Class