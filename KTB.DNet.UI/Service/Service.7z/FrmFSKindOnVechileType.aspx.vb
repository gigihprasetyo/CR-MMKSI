#Region "Custom Namespace Imports"
Imports KTB.DNet.Domain
Imports KTB.DNet.BusinessFacade.Service
Imports KTB.DNet.BusinessFacade.Helper
Imports KTB.DNet.BusinessFacade.FinishUnit
Imports KTB.DNet.Utility
Imports KTB.DNet.Domain.Search
Imports KTB.DNet.Security
#End Region

Public Class FrmFSKindOnVechileType
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents btnSimpan As System.Web.UI.WebControls.Button
    Protected WithEvents btnBatal As System.Web.UI.WebControls.Button
    Protected WithEvents dtgFSKind As System.Web.UI.WebControls.DataGrid
    Protected WithEvents ddlCategory As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlVehicleType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlFSKind As System.Web.UI.WebControls.DropDownList
    Protected WithEvents btnCari As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Private Variable"
    Private objDealer As Dealer
    Private sessHelper As SessionHelper = New SessionHelper
    Private m_bFormPrivilege As Boolean = False
#End Region

#Region "Form's Event"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        ActivateUserPrivilege()
        If Not IsPostBack Then
            InitiatePage()
            ViewState("vsSearchVehicleType") = "Load"
            BindDataGrid(0)
        End If
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If ddlCategory.SelectedIndex = 0 Then
            MessageBox.Show("Silahkan pilih Kategori")
            Return
        End If

        If ddlVehicleType.SelectedIndex = 0 Then
            MessageBox.Show("Silahkan pilih Tipe")
            Return
        End If

        If ddlFSKind.SelectedIndex = 0 Then
            MessageBox.Show("Silahkan pilih Jenis Free Service")
            Return
        End If

        Dim companyCode As String = KTB.DNet.Lib.WebConfig.GetValue("CompanyCode")
        Dim categoryArr As ArrayList = New CategoryFacade(User).RetrieveActiveList(companyCode)
        Dim valid As Boolean = False
        For Each item As Category In categoryArr
            If ddlCategory.SelectedValue = item.ID Then
                valid = True
            End If
        Next


        If valid Then
            Simpan()
        Else
            MessageBox.Show("Kategori tidak sesuai")
        End If

    End Sub

    Private Sub btnBatal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        ClearData()
        dtgFSKind.CurrentPageIndex = 0
        dtgFSKind.SelectedIndex = -1
        BindDataGrid(dtgFSKind.CurrentPageIndex)
    End Sub
    Private Sub btnCari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCari.Click
        ViewState("vsSearchVehicleType") = "Search"
        dtgFSKind.CurrentPageIndex = 0
        BindDataGrid(dtgFSKind.CurrentPageIndex)
    End Sub
    Private Sub dtgFSKind_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dtgFSKind.ItemDataBound
        If e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.Item Then

            If Not e.Item.FindControl("lbtnDelete") Is Nothing Then
                CType(e.Item.FindControl("lbtnDelete"), LinkButton).Attributes.Add("OnClick", "return confirm('" & SR.DeleteConfirmation & "');")
            End If

            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
                CType(e.Item.FindControl("lblNo"), Label).Text = CType(e.Item.ItemIndex + 1 + (dtgFSKind.CurrentPageIndex * dtgFSKind.PageSize), String)
            End If

            If Not e.Item.FindControl("lbtnEdit") Is Nothing Then
                CType(e.Item.FindControl("lbtnEdit"), LinkButton).Visible = m_bFormPrivilege
            End If

            If Not e.Item.FindControl("lbtnDelete") Is Nothing Then
                CType(e.Item.FindControl("lbtnDelete"), LinkButton).Visible = m_bFormPrivilege
            End If

        End If
    End Sub

    Private Sub dtgFSKind_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dtgFSKind.ItemCommand
        If (e.CommandName = "View") Then
            ViewState.Add("vsProcess", "View")
            Try
                LoadObjectToForm(e.Item.Cells(0).Text, False)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        ElseIf e.CommandName = "Edit" Then
            ViewState.Add("vsProcess", "Edit")
            Try
                LoadObjectToForm(e.Item.Cells(0).Text, True)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
            dtgFSKind.SelectedIndex = e.Item.ItemIndex
        ElseIf e.CommandName = "Delete" Then
            Delete(e.Item.Cells(0).Text)
        End If
    End Sub

    Private Sub dtgFSKind_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dtgFSKind.PageIndexChanged
        dtgFSKind.SelectedIndex = -1
        dtgFSKind.CurrentPageIndex = e.NewPageIndex
        BindDataGrid(dtgFSKind.CurrentPageIndex)
    End Sub

    Private Sub dtgFSKind_SortCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridSortCommandEventArgs) Handles dtgFSKind.SortCommand
        If CType(ViewState("vsSortColumn"), String) = e.SortExpression Then
            Select Case CType(ViewState("vsSortDirect"), Sort.SortDirection)
                Case Sort.SortDirection.ASC
                    ViewState("vsSortDirect") = Sort.SortDirection.DESC
                Case Sort.SortDirection.DESC
                    ViewState("vsSortDirect") = Sort.SortDirection.ASC
            End Select
        Else
            ViewState("vsSortColumn") = e.SortExpression
            ViewState("vsSortDirect") = Sort.SortDirection.ASC
        End If
        dtgFSKind.SelectedIndex = -1
        dtgFSKind.CurrentPageIndex = 0
        BindDataGrid(dtgFSKind.CurrentPageIndex)
        ClearData()
    End Sub

    Private Sub ddlCategory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCategory.SelectedIndexChanged
        btnSimpan.Enabled = False
        If ddlCategory.SelectedIndex > 0 Then
            btnSimpan.Enabled = True
            BindDdlType()
        End If
    End Sub
#End Region

#Region "Private Method"
    Private Sub ActivateUserPrivilege()
        m_bFormPrivilege = SecurityProvider.Authorize(Context.User, SR.ServiceJenisFSUpdate_Privilege)

        If Not SecurityProvider.Authorize(Context.User, SR.ServiceJenisFSView_Privilege) Then
            Server.Transfer("../FrmAccessDenied.aspx?modulName=FREE SERVICE - Form Jenis Free Service")
        End If
    End Sub

    Private Sub SetControlPrivilege()
        btnSimpan.Visible = m_bFormPrivilege
        btnBatal.Visible = m_bFormPrivilege
    End Sub

    Private Sub InitiatePage()
        ClearData()
        SetControlPrivilege()
        ViewState("vsSortColumn") = "VechileType.Category.CategoryCode"
        ViewState("vsSortDirect") = Sort.SortDirection.ASC
    End Sub

    Private Sub ClearData()
        BindDdlCategory()
        BindDdlType()
        BindFSType()
        ViewState("vsProcess") = "Insert"
        btnSimpan.Enabled = False
        ddlCategory.Enabled = True
        ddlVehicleType.Enabled = True
        ddlFSKind.Enabled = True
    End Sub

    Private Sub BindDataGrid(ByVal index As Integer)
        Dim data As ArrayList
        Try
            Dim totalRow As Integer = 0
            If ViewState("vsSearchVehicleType") = "Load" Then
                data = New FSKindOnVechileTypeFacade(User).RetrieveActiveList(index + 1, dtgFSKind.PageSize, totalRow, ViewState("vsSortColumn"), ViewState("vsSortDirect"))
            Else

                Dim criterias As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(KTB.DNet.Domain.FSKindOnVechileType), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))

                If ddlCategory.SelectedIndex <> 0 Then
                    criterias.opAnd(New Criteria(GetType(KTB.DNet.Domain.FSKindOnVechileType), "VechileType.Category.ID", MatchType.Exact, CType(ddlCategory.SelectedValue, Integer)))
                End If
                If ddlVehicleType.SelectedIndex <> 0 Then
                    criterias.opAnd(New Criteria(GetType(KTB.DNet.Domain.FSKindOnVechileType), "VechileType.ID", MatchType.Exact, CType(ddlVehicleType.SelectedValue, Integer)))
                End If
                If ddlFSKind.SelectedIndex <> 0 Then
                    criterias.opAnd(New Criteria(GetType(KTB.DNet.Domain.FSKindOnVechileType), "FSKind.ID", MatchType.Exact, CType(ddlFSKind.SelectedValue, Integer)))
                End If

                data = New FSKindOnVechileTypeFacade(User).RetrieveActiveList(criterias, index + 1, dtgFSKind.PageSize, _
                      totalRow, CType(ViewState("vsSortColumn"), String), _
                CType(ViewState("vsSortDirect"), Sort.SortDirection))

            End If
            dtgFSKind.DataSource = data
            dtgFSKind.VirtualItemCount = totalRow
            dtgFSKind.DataBind()
        Catch ex As Exception
            dtgFSKind.DataSource = Nothing
            dtgFSKind.VirtualItemCount = 0
            dtgFSKind.DataBind()
            'MessageBox.Show(ex.Message.ToString)
        End Try

    End Sub

    Private Sub BindDdlCategory()
        ddlCategory.Items.Clear()

        Dim critCol As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(Category), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        Dim sortCol As SortCollection = New SortCollection
        sortCol.Add(New Sort(GetType(Category), "CategoryCode", Sort.SortDirection.ASC))
        Dim objCategory As ArrayList = New CategoryFacade(User).Retrieve(critCol, sortCol)

        Dim li As ListItem
        For Each oneCategory As Category In objCategory
            li = New ListItem(oneCategory.CategoryCode, oneCategory.ID.ToString)
            ddlCategory.Items.Add(li)
        Next

        li = New ListItem("Silahkan pilih", "0")
        ddlCategory.Items.Insert(0, li)
    End Sub

    Private Sub BindDdlType()
        ddlVehicleType.Items.Clear()
        Dim li As ListItem

        li = New ListItem("Silahkan pilih", "0")
        ddlVehicleType.Items.Add(li)

        If ddlCategory.SelectedIndex = 0 Then
            Return
        End If

        Dim CategoryID As Integer = Integer.Parse(ddlCategory.SelectedValue)

        Dim critCol As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(VechileType), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        critCol.opAnd(New Criteria(GetType(VechileType), "Category.ID", MatchType.Exact, CategoryID))
        Dim sortCol As SortCollection = New SortCollection
        sortCol.Add(New Sort(GetType(VechileType), "VechileTypeCode", Sort.SortDirection.ASC))
        Dim objVehicleType As ArrayList = New VechileTypeFacade(User).Retrieve(critCol, sortCol)


        For Each oneVehicleType As VechileType In objVehicleType
            li = New ListItem(oneVehicleType.VechileTypeCode, oneVehicleType.ID.ToString)
            ddlVehicleType.Items.Add(li)
        Next

        btnSimpan.Enabled = True
    End Sub

    Private Sub BindFSType()
        ddlFSKind.Items.Clear()
        Dim critCol As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(FSKind), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        Dim sortCol As SortCollection = New SortCollection
        sortCol.Add(New Sort(GetType(FSKind), "ID", Sort.SortDirection.ASC))
        Dim objFSKind As ArrayList = New FSKindFacade(User).Retrieve(critCol, sortCol)

        Dim li As ListItem
        For Each oneFSKind As FSKind In objFSKind
            li = New ListItem(oneFSKind.KindDescription, oneFSKind.ID.ToString)
            ddlFSKind.Items.Add(li)
        Next

        li = New ListItem("Silahkan pilih", "0")
        ddlFSKind.Items.Insert(0, li)
    End Sub

    Private Sub Simpan()
        Try
            If ViewState("vsProcess") = "Insert" Then
                Insert()
            ElseIf ViewState("vsProcess") = "Edit" Then
                Edit()
            End If
        Catch
            MessageBox.Show(SR.SaveFail)
            ClearData()
            dtgFSKind.CurrentPageIndex = 0
            dtgFSKind.SelectedIndex = -1
            BindDataGrid(dtgFSKind.CurrentPageIndex)
        End Try
    End Sub

    Private Sub Insert()
        Dim objData As FSKindOnVechileType = New FSKindOnVechileType
        LoadFormToObject(objData)
        If IsExist(objData) Then
            MessageBox.Show(SR.DataIsExist("Jenis Free Service"))
        Else
            Dim objFacade As FSKindOnVechileTypeFacade = New FSKindOnVechileTypeFacade(User)
            Dim result As Integer = objFacade.Insert(objData)
            If result > 0 Then
                MessageBox.Show(SR.SaveSuccess)
                ClearData()
                dtgFSKind.CurrentPageIndex = 0
                dtgFSKind.SelectedIndex = -1
                BindDataGrid(dtgFSKind.CurrentPageIndex)
            Else
                MessageBox.Show(SR.SaveFail)
            End If
        End If
    End Sub

    Private Sub Edit()
        Dim objData As FSKindOnVechileType = sessHelper.GetSession("objFSKindOnVehicleType")
        If IsNothing(objData) Then
            MessageBox.Show(SR.DataNotFound("Jenis Free Service"))
            Return
        End If

        Dim newData As FSKindOnVechileType = New FSKindOnVechileType
        LoadFormToObject(newData)

        If objData.FSKind.ID = newData.FSKind.ID And objData.VechileType.ID = newData.VechileType.ID Then
            MessageBox.Show(SR.SaveSuccess)
            ClearData()
            dtgFSKind.CurrentPageIndex = 0
            dtgFSKind.SelectedIndex = -1
            BindDataGrid(dtgFSKind.CurrentPageIndex)
            Return
        End If

        objData.FSKind = newData.FSKind
        objData.VechileType = newData.VechileType

        If IsExist(objData) Then
            MessageBox.Show(SR.DataNotFound("Jenis Free Service"))
            Return
        End If

        Dim objFacade As FSKindOnVechileTypeFacade = New FSKindOnVechileTypeFacade(User)
        Dim result As Integer = objFacade.Update(objData)
        If result > 0 Then
            MessageBox.Show(SR.SaveSuccess)
            ClearData()
            dtgFSKind.CurrentPageIndex = 0
            dtgFSKind.SelectedIndex = -1
            BindDataGrid(dtgFSKind.CurrentPageIndex)
        Else
            MessageBox.Show(SR.SaveFail)
        End If
    End Sub

    Private Sub LoadFormToObject(ByVal obj As FSKindOnVechileType)
        Dim objFSKind As FSKind = New FSKindFacade(User).Retrieve(CInt(ddlFSKind.SelectedValue))
        Dim objVehicleType As VechileType = New VechileTypeFacade(User).Retrieve(CInt(ddlVehicleType.SelectedValue))
        If IsNothing(objFSKind) Or objFSKind.ID = 0 Then
            Throw New Exception(SR.DataNotFound("Jenis Free Service"))
        End If
        If IsNothing(objVehicleType) Or objVehicleType.ID = 0 Then
            Throw New Exception(SR.DataNotFound("Tipe Service"))
        End If
        obj.FSKind = objFSKind
        obj.VechileType = objVehicleType
    End Sub

    Private Sub LoadObjectToForm(ByVal nID As Integer, ByVal Editable As Boolean)
        Try
            Dim obj As FSKindOnVechileType = New FSKindOnVechileTypeFacade(User).Retrieve(nID)
            If IsNothing(obj) Or obj.ID = 0 Then
                Throw New Exception(SR.DataNotFound("Jenis Free Service"))
            End If

            SetDdlCategory(obj)
            SetDdlFSKind(obj)

            sessHelper.SetSession("objFSKindOnVehicleType", obj)
        Catch ex As Exception
            Throw ex
        Finally
            ddlCategory.Enabled = Editable
            ddlVehicleType.Enabled = Editable
            ddlFSKind.Enabled = Editable
            btnSimpan.Enabled = Editable
        End Try
    End Sub

    Private Sub SetDdlCategory(ByVal obj As FSKindOnVechileType)
        Dim li As ListItem = ddlCategory.Items.FindByValue(obj.VechileType.Category.ID.ToString)
        If IsNothing(li) Then
            Throw New Exception(SR.DataNotFound("Kategori"))
        End If

        ddlCategory.SelectedIndex = ddlCategory.Items.IndexOf(li)

        BindDdlType()
        SetDdlVehicleType(obj)
    End Sub

    Private Sub SetDdlVehicleType(ByVal obj As FSKindOnVechileType)
        Dim li As ListItem = ddlVehicleType.Items.FindByValue(obj.VechileType.ID.ToString)
        If IsNothing(li) Then
            Throw New Exception(SR.DataNotFound("Tipe"))
        End If

        ddlVehicleType.SelectedIndex = ddlVehicleType.Items.IndexOf(li)
    End Sub

    Private Sub SetDdlFSKind(ByVal obj As FSKindOnVechileType)
        Dim li As ListItem = ddlFSKind.Items.FindByValue(obj.FSKind.ID.ToString)
        If IsNothing(li) Then
            Throw New Exception(SR.DataNotFound("Tipe"))
        End If

        ddlFSKind.SelectedIndex = ddlFSKind.Items.IndexOf(li)
    End Sub

    Private Function IsExist(ByVal obj As FSKindOnVechileType) As Boolean
        Dim critComp As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(FSKindOnVechileType), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        critComp.opAnd(New Criteria(GetType(FSKindOnVechileType), "FSKind.ID", MatchType.Exact, obj.FSKind.ID))
        critComp.opAnd(New Criteria(GetType(FSKindOnVechileType), "VechileType.ID", MatchType.Exact, obj.VechileType.ID))

        Return New FSKindOnVechileTypeFacade(User).Retrieve(critComp).Count > 0
    End Function

    Private Function IsExist(ByVal obj As FSKindOnVechileType, ByVal newData As FSKindOnVechileType) As Boolean
        Dim critComp As CriteriaComposite = New CriteriaComposite(New Criteria(GetType(FSKindOnVechileType), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        critComp.opAnd(New Criteria(GetType(FSKindOnVechileType), "FSKind.ID", MatchType.Exact, obj.FSKind.ID))
        critComp.opAnd(New Criteria(GetType(FSKindOnVechileType), "VechileType.ID", MatchType.Exact, obj.VechileType.ID))
        critComp.opAnd(New Criteria(GetType(FSKindOnVechileType), "FSKind.ID", MatchType.No, newData.FSKind.ID))
        critComp.opAnd(New Criteria(GetType(FSKindOnVechileType), "VechileType.ID", MatchType.No, newData.VechileType.ID))

        Return New FSKindOnVechileTypeFacade(User).Retrieve(critComp).Count > 0
    End Function

    Private Sub Delete(ByVal nID As Integer)
        Dim objFacade As FSKindOnVechileTypeFacade = New FSKindOnVechileTypeFacade(User)
        Dim deletedData As FSKindOnVechileType = objFacade.Retrieve(nID)
        If IsNothing(deletedData) Or deletedData.ID = 0 Then
            MessageBox.Show(SR.DataNotFound("Jenis Free Service"))
        Else
            Try
                Dim nResult = objFacade.DeleteFromDB(deletedData)
                If nResult <= 0 Then
                    MessageBox.Show(SR.DeleteFail)
                Else
                    MessageBox.Show(SR.DeleteSucces)
                End If
            Catch
                MessageBox.Show(SR.DeleteSucces)
            End Try
        End If
        ClearData()
        dtgFSKind.CurrentPageIndex = 0
        dtgFSKind.SelectedIndex = -1
        BindDataGrid(dtgFSKind.CurrentPageIndex)
    End Sub


#End Region


    
End Class
