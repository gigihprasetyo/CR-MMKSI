﻿Imports KTB.DNet.Utility
Imports KTB.DNet.Domain
Imports KTB.DNet.Domain.Search
Imports KTB.DNet.BusinessFacade
Imports KTB.DNet.BusinessFacade.FinishUnit
Imports KTB.DNet.BusinessFacade.DealerReport
Imports KTB.DNet.BusinessFacade.General
Imports KTB.DNet.UI.Helper
Imports KTB.DNet.Security
Imports System.IO
Imports System.Text
Imports KTB.DNet.WebApi.Models
Imports KTB.DNet.WebApi.Models.SalesForce

Public Class FrmCustomerCaseResponse
    Inherits System.Web.UI.Page


#Region "Private Variable"
    Private oDealer, objDealer As Dealer
    Private sessHelper As New SessionHelper
    Private _arrDeliveryCustomerHeader As ArrayList
    Private dt As DateTime = DateTime.Now
    Private TotalUnit As Integer
    Private Suffix As String = CType(dt.Year, String) & CType(dt.Month, String) & CType(dt.Day, String) & CType(dt.Hour, String) & CType(dt.Minute, String) & CType(dt.Second, String) & CType(dt.Millisecond, String)
    Private bEditPriv As Boolean
    Private bViewPriv As Boolean
    Private bDownloadPriv As Boolean
#End Region

#Region " Event Handler"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        InitiateAuthorization()

        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        oDealer = CType(sessHelper.GetSession("DEALER"), Dealer)

        If Not IsPostBack Then
            BindStatus()
            If Not IsNothing(Request.QueryString("caseId")) Then
                Dim _CustomerCaseID As Integer = CInt(Request.QueryString("caseId"))
                sessHelper.SetSession("SessCustomerCaseID", _CustomerCaseID)
                If Not IsNothing(Request.QueryString("mode")) Then
                    Dim _mode As String = Request.QueryString("mode")
                    BindDataCustomerCase(_CustomerCaseID, _mode)
                Else
                    BindDataCustomerCase(_CustomerCaseID, "view")
                End If
            Else
                ClearForm()
            End If
        End If
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim bolNotValidSave As Boolean = False
        If ddlStatus.SelectedIndex = 0 Then 'validasi Status blank
            lblValidddlStatus.Text = "*"
            bolNotValidSave = True
        End If
        If txtComment.Text.Trim() = "" Then 'validasi Comment blank
            lblValidtxtComment.Text = "*"
            bolNotValidSave = True
        End If
        'Validasi File Upload kosong jika status closed
        If (Not EvidenceFile.PostedFile Is Nothing) Then
            If (EvidenceFile.PostedFile.ContentLength <= 0 Or EvidenceFile.PostedFile.FileName.Trim() = String.Empty) Then
                If ddlStatus.SelectedValue.Trim() = EnumCustomerCaseResponse.CustomerCaseResponse.Closed Then 'Status Closed
                    lblValidFile.Text = "*"
                    bolNotValidSave = True
                End If
            End If
        End If
        If bolNotValidSave = True Then
            Return
        End If

        'Validasi Upload file type jpg,jpeg, bmp, png, pdf dan maks size file 1 Mb
        Dim blnNotValid1 As Boolean = False, blnNotValid2 As Boolean = False
        If Not IsNothing(EvidenceFile.PostedFile) Then
            If (Not (EvidenceFile.PostedFile.FileName.Trim() = String.Empty)) Then
                Dim fileSize As Integer = EvidenceFile.PostedFile.ContentLength
                ' 1MB -> 1000 * 1024
                If (fileSize >= 1024000 Or fileSize < 0) Then
                    blnNotValid1 = True
                End If
                If ((Not Path.GetExtension(EvidenceFile.PostedFile.FileName).ToLower() = ".jpg") And
                    (Not Path.GetExtension(EvidenceFile.PostedFile.FileName).ToLower() = ".jpeg") And
                    (Not Path.GetExtension(EvidenceFile.PostedFile.FileName).ToLower() = ".bmp") And
                    (Not Path.GetExtension(EvidenceFile.PostedFile.FileName).ToLower() = ".png") And
                    (Not Path.GetExtension(EvidenceFile.PostedFile.FileName).ToLower() = ".pdf")) Then
                    blnNotValid2 = True
                End If

                If blnNotValid1 = True Or blnNotValid2 = True Then
                    MessageBox.Show("Maksimum upload file 1 MB dan file harus berekstensi: jpg, jpeg, bmp, png dan pdf")
                    Return
                End If
            End If
        End If

        'Validasi error upload file
        If (Not EvidenceFile.PostedFile.FileName = String.Empty) Then
            If Not CopyFileToServer() Then
                MessageBox.Show("Upload file gagal")
                Return
            End If
        End If

        If CType(ViewState("vsProcess"), String) = "Insert" Then
            InsertCustomerCaseResponse()
        Else
            UpdateCustomerCaseResponse()
        End If
        btnBatal_Click(sender, e)

    End Sub

    Protected Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        ViewState.Clear()
        Response.Redirect("FrmCustomerCase.aspx?isBack=1")
    End Sub

#End Region

#Region "Custom Method"
    Private Sub InitiateAuthorization()
        'If Not SecurityProvider.Authorize(Context.User, SR.KirimKendaraanListView_Privilege) Then
        '    Server.Transfer("../FrmAccessDenied.aspx?modulName=Marketing - Case Management")
        'End If

        'bViewPriv = SecurityProvider.Authorize(Context.User, SR.KirimKendaraanListView_Privilege)
        'bEditPriv = SecurityProvider.Authorize(Context.User, SR.KirimKendaraanListEdit_Privilege)
        'bDownloadPriv = SecurityProvider.Authorize(Context.User, SR.KirimKendaraanListDownload_Privilege)
    End Sub

    Private Sub ClearForm()
        lblDealer.Text = String.Empty
        lblCustomerName.Text = String.Empty
        lblPhone.Text = String.Empty
        lblEmail.Text = String.Empty
        lblVehicleType.Text = String.Empty
        lblVariant.Text = String.Empty
        lblEngineNo.Text = String.Empty
        lblChassisNo.Text = String.Empty
        lblNoPol.Text = String.Empty
        lblOdometer.Text = String.Empty

        lblCaseNumber.Text = String.Empty
        lblCaseNumberRef.Text = String.Empty
        lblCaseDate.Text = String.Empty
        lblCategory.Text = String.Empty
        lblCategory1.Text = String.Empty
        lblCategory2.Text = String.Empty
        lblCategory3.Text = String.Empty
        lblCategory4.Text = String.Empty
        lblType.Text = String.Empty
        lblSubject.Text = String.Empty
        lblDescription.Text = String.Empty

        dgCase.VirtualItemCount = 0
        dgCase.DataSource = Nothing
        dgCase.DataBind()

        EvidenceFile.Visible = True
        LblEvidenceFile.Visible = False
        lbtnDelEvidenceFile.Visible = False
        hdnDestFile.Value = ""
        LblEvidenceFile.Text = ""

        ddlStatus.Enabled = True
        ViewState.Add("vsProcess", "Insert")
    End Sub

    Private Sub BindStatus()
        Dim arl As ArrayList = EnumCustomerCaseResponse.RetriveCustomerPurpose(True)
        ddlStatus.Items.Clear()
        For Each item As EnumCustomerCaseResponseOp In arl
            If (Not item.ValStatus = EnumCustomerCaseResponse.CustomerCaseResponse.NewStatus) AndAlso (Not item.ValStatus = EnumCustomerCaseResponse.CustomerCaseResponse.Re_Open) Then
                ddlStatus.Items.Add(New ListItem(item.NameStatus, item.ValStatus))
            End If
        Next
    End Sub

    Private Sub BindDataCustomerCase(ByVal _customerCaseID As Integer, ByVal mode As String)
        Dim arr As New ArrayList
        Dim total As Integer

        Dim objCustomerCase As CustomerCase = New CustomerCaseFacade(User).Retrieve(_customerCaseID)
        If Not IsNothing(objCustomerCase) AndAlso objCustomerCase.ID > 0 Then
            sessHelper.SetSession("SessCustomerCase", objCustomerCase)
            lblDealer.Text = objCustomerCase.Dealer.DealerCode
            lblCustomerName.Text = objCustomerCase.CustomerName
            lblPhone.Text = objCustomerCase.Phone
            lblEmail.Text = objCustomerCase.Email
            lblVehicleType.Text = objCustomerCase.CarType
            lblVariant.Text = objCustomerCase.Variants
            lblEngineNo.Text = objCustomerCase.EngineNumber
            lblChassisNo.Text = objCustomerCase.ChassisNumber
            lblNoPol.Text = objCustomerCase.PlateNumber
            lblOdometer.Text = objCustomerCase.Odometer

            lblCaseNumber.Text = objCustomerCase.CaseNumber
            lblCaseNumberRef.Text = objCustomerCase.CaseNumberReff
            lblCaseDate.Text = objCustomerCase.CaseDate
            lblCategory.Text = objCustomerCase.Category
            lblCategory1.Text = objCustomerCase.SubCategory1
            lblCategory2.Text = objCustomerCase.SubCategory2
            lblCategory3.Text = objCustomerCase.SubCategory3
            lblCategory4.Text = objCustomerCase.SubCategory4
            lblType.Text = objCustomerCase.CallerType
            lblSubject.Text = objCustomerCase.Subject
            lblDescription.Text = objCustomerCase.Description
        End If

        If mode = "edit" Then
            pnlEntry.Visible = True
            btnSave.Visible = True
        Else
            pnlEntry.Visible = False
            btnSave.Visible = False
        End If

        BindDataResponse(dgCase.CurrentPageIndex)

    End Sub

    Private Sub BindDataResponse(ByVal iPage As Integer)
        Dim arr As New ArrayList
        Dim total As Integer
        Dim objCustomerCase As CustomerCase = CType(sessHelper.GetSession("SessCustomerCase"), CustomerCase)
        Dim _criterias As New CriteriaComposite(New Criteria(GetType(CustomerCaseResponse), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
        _criterias.opAnd(New Criteria(GetType(CustomerCaseResponse), "CustomerCase.ID", MatchType.Exact, objCustomerCase.ID))

        Dim sortColl As SortCollection = New SortCollection
        sortColl.Add(New Sort(GetType(CustomerCaseResponse), "CreatedTime", Sort.SortDirection.ASC))

        'arr = New CustomerCaseResponseFacade(User).RetrieveByCriteria(_criterias, iPage, dgCase.PageSize, total)
        arr = New CustomerCaseResponseFacade(User).Retrieve(_criterias, sortColl)

        dgCase.VirtualItemCount = total
        dgCase.DataSource = arr
        dgCase.DataBind()

        If arr.Count > 0 Then
            Dim objCustResp As CustomerCaseResponse = CType(arr(arr.Count - 1), CustomerCaseResponse)
            'comment : ddlStatus defaultnya 'Silahkan Pilih/Kosong'
            'ddlStatus.SelectedValue = CType(objCustResp.Status, String)

            If objCustResp.Status = EnumCustomerCaseResponse.CustomerCaseResponse.Closed Then
                ddlStatus.Enabled = False
                txtComment.Enabled = False
                EvidenceFile.Disabled = True
            End If
            dgCase.SelectedIndex = -1
        End If

        ViewState.Add("vsProcess", "Insert")
        hdnDestFile.Value = ""
        LblEvidenceFile.Text = ""
        EvidenceFile.Visible = True
        LblEvidenceFile.Visible = False
        lbtnDelEvidenceFile.Visible = False
    End Sub

    Private Function CopyFileToServer() As Boolean
        If CopyFile(EvidenceFile) Then
            Return True
        Else
            Return False
        End If
    End Function
    Private Function CopyFile(ByVal DataFile As HtmlInputFile) As Boolean
        If (Not EvidenceFile.PostedFile Is Nothing) And (DataFile.PostedFile.ContentLength > 0) And (DataFile.PostedFile.ContentLength <= 1000000) Then
            Dim SrcFile As String = Path.GetFileName(DataFile.PostedFile.FileName) '-- Source file name
            Dim fname As String = Path.GetFileNameWithoutExtension(DataFile.PostedFile.FileName)
            Dim DestFile As String = KTB.DNet.Lib.WebConfig.GetValue("CaseEvidenceFileDirectory") & "\" & lblDealer.Text & "\" & lblCaseNumber.Text & "\" & fname & "_" & TimeStamp() & SrcFile.Substring(SrcFile.Length - 4)  '-- Destination file

            Dim fileInfo1 As New FileInfo(KTB.DNet.Lib.WebConfig.GetValue("SAN"))

            Dim DestFullFilePath As String = fileInfo1.Directory.FullName & "\" & DestFile '-- Destination file
            Dim fileInfoDestination As New FileInfo(DestFullFilePath)
            Dim _user As String = KTB.DNet.Lib.WebConfig.GetValue("User")
            Dim _password As String = KTB.DNet.Lib.WebConfig.GetValue("Password")
            Dim _webServer As String = KTB.DNet.Lib.WebConfig.GetValue("WebServer")
            Dim imp As SAPImpersonate = New SAPImpersonate(_user, _password, _webServer)
            Dim success As Boolean = False
            Dim helper As FileHelper = New FileHelper
            Try
                success = imp.Start()
                If success Then
                    If Not fileInfoDestination.Exists Then
                        fileInfoDestination.Directory.Create()
                    End If
                    DataFile.PostedFile.SaveAs(DestFullFilePath)
                    imp.StopImpersonate()
                    imp = Nothing
                    hdnDestFile.Value = DestFile
                    Return True
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End If
        Return False
    End Function

    Private Function TimeStamp() As String
        Return DateTime.Now.Year & DateTime.Now.Month & DateTime.Now.Day & DateTime.Now.Hour & DateTime.Now.Minute & DateTime.Now.Second & DateTime.Now.Millisecond
    End Function

    Private Function UpdateCustomerCaseResponse()
        Dim objCustomerCaseResponse As CustomerCaseResponse = CType(Session.Item("vsCustomerCaseResponse"), CustomerCaseResponse)
        Dim objCustomerCase As CustomerCase = CType(sessHelper.GetSession("sessCustomerCase"), CustomerCase)
        objCustomerCaseResponse.CustomerCase = objCustomerCase
        objCustomerCaseResponse.Status = ddlStatus.SelectedValue
        objCustomerCaseResponse.Description = txtComment.Text
        objCustomerCaseResponse.EvidenceFile = hdnDestFile.Value

        Dim fileInfo1 As New FileInfo(KTB.DNet.Lib.WebConfig.GetValue("SAN"))
        Dim DestFullFilePath As String = fileInfo1.Directory.FullName & "\" & LblEvidenceFile.Text
        Dim fileInfoDestination As New FileInfo(DestFullFilePath)
        Dim _user As String = KTB.DNet.Lib.WebConfig.GetValue("User")
        Dim _password As String = KTB.DNet.Lib.WebConfig.GetValue("Password")
        Dim _webServer As String = KTB.DNet.Lib.WebConfig.GetValue("WebServer")
        Dim imp As SAPImpersonate = New SAPImpersonate(_user, _password, _webServer)
        Dim success As Boolean = False
        Dim helper As FileHelper = New FileHelper
        Try
            success = imp.Start()
            If success Then
                If fileInfoDestination.Exists Then
                    fileInfoDestination.Delete()
                End If
                imp.StopImpersonate()
                imp = Nothing
            End If
        Catch ex As Exception
            Throw ex
        End Try

        Dim nResult As Integer = -1
        Try
            nResult = New CustomerCaseResponseFacade(User).Update(objCustomerCaseResponse)
        Catch ex As Exception
            nResult = -1
        End Try

        If nResult <> -1 Then
            'btnSave.Enabled = False
            BindDataResponse(dgCase.CurrentPageIndex)
            Dim sender As Object
            MessageBox.Show(SR.UpdateSucces)
        Else
            MessageBox.Show(SR.UpdateFail)
        End If
    End Function

    Private Function InsertCustomerCaseResponse()
        Dim objFacade As CustomerCaseResponseFacade = New CustomerCaseResponseFacade(User)
        Dim objCustomerCase As CustomerCase = CType(sessHelper.GetSession("sessCustomerCase"), CustomerCase)
        Dim objresponse As CustomerCaseResponse = New CustomerCaseResponse
        objresponse.CustomerCase = objCustomerCase
        'objresponse.Subject = txtSubject.Text
        objresponse.Status = ddlStatus.SelectedValue
        objresponse.EvidenceFile = hdnDestFile.Value
        objresponse.Description = txtComment.Text

        '1. Insert to CustomerCaseResponse
        '2. Update Status to CustomerCase
        Dim nResult As Integer = 0
        Dim nResult2 As Integer = 0
        Try
            nResult = objFacade.Insert(objresponse)
            If Not (objCustomerCase Is Nothing) Then
                objCustomerCase.Status = ddlStatus.SelectedValue
                nResult2 = New CustomerCaseFacade(User).Update(objCustomerCase)
            End If
        Catch ex As Exception
            nResult = -1
        End Try

        If nResult <> -1 Then
            'btnSave.Enabled = False
            BindDataResponse(dgCase.CurrentPageIndex)
            MessageBox.Show(SR.SaveSuccess)

            Dim sf As SalesForceInterface = New SalesForceInterface()
            Dim msg As String = String.Empty
            Dim vSFreturn As Boolean = False
            vSFreturn = sf.UpdateCase(objresponse)

            Dim arr = New ArrayList
            Dim _criterias As New CriteriaComposite(New Criteria(GetType(WsLog), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
            _criterias.opAnd(New Criteria(GetType(WsLog), "Message", MatchType.Exact, String.Empty))
            _criterias.opOr(New Criteria(GetType(WsLog), "Message", MatchType.Exact, vbNull))
            _criterias.opAnd(New Criteria(GetType(WsLog), "Source", MatchType.Exact, "Internal"))
            _criterias.opAnd(New Criteria(GetType(WsLog), "Status", MatchType.Exact, "False"))
            _criterias.opAnd(New Criteria(GetType(WsLog), "Body", MatchType.[Partial], "SALESFORCEIUPDATECASE"))
            _criterias.opAnd(New Criteria(GetType(WsLog), "Body", MatchType.[Partial], objCustomerCase.SalesforceID))
            arr = New WsLogFacade(User).Retrieve(_criterias)

            If vSFreturn Or arr.Count > 0 Then
                'Update IsSend
                Dim objResponseNew As CustomerCaseResponse = New CustomerCaseResponse()
                If objresponse.ID > 0 Then
                    objResponseNew = New CustomerCaseResponseFacade(User).Retrieve(objresponse.ID)
                Else
                    objResponseNew = New CustomerCaseResponseFacade(User).Retrieve(nResult)
                End If
                objResponseNew.IsSend = 1 'sent
                nResult = New CustomerCaseResponseFacade(User).Update(objResponseNew)
            End If
        Else
            MessageBox.Show(SR.SaveFail)
        End If
    End Function

    Private Sub ViewCustomerCaseResponse(ByVal nID As Integer, ByVal EditStatus As Boolean)
        Dim objCustomerCaseResponse As CustomerCaseResponse = New CustomerCaseResponseFacade(User).Retrieve(nID)
        sessHelper.SetSession("vsCustomerCaseResponse", objCustomerCaseResponse)

        ddlStatus.SelectedValue = CType(objCustomerCaseResponse.Status, String)
        txtComment.Text = objCustomerCaseResponse.Description
        Dim EvidenceFileOnlyName As String = objCustomerCaseResponse.EvidenceFile.Substring(objCustomerCaseResponse.EvidenceFile.LastIndexOf("\") + 1)
        hdnDestFile.Value = objCustomerCaseResponse.EvidenceFile
        LblEvidenceFile.Text = EvidenceFileOnlyName

        If LblEvidenceFile.Text.Trim() = "" Then
            LblEvidenceFile.Visible = False
            lbtnDelEvidenceFile.Visible = False
            EvidenceFile.Visible = True
        Else
            LblEvidenceFile.Visible = True
            lbtnDelEvidenceFile.Visible = True
            EvidenceFile.Visible = False
        End If

        btnSave.Enabled = EditStatus
    End Sub

#End Region

    Private Sub dgCase_ItemCommand(source As Object, e As DataGridCommandEventArgs) Handles dgCase.ItemCommand
        Select Case e.CommandName
            Case "Download"
                Dim objCustomerCaseResponse As CustomerCaseResponse = New CustomerCaseResponseFacade(User).Retrieve(CInt(e.CommandArgument))
                If Not IsNothing(objCustomerCaseResponse) Then
                    If Not objCustomerCaseResponse.EvidenceFile.Trim = "" Then
                        Dim fileInfo1 As New FileInfo(KTB.DNet.Lib.WebConfig.GetValue("SAN"))
                        Dim PathFile As String = fileInfo1.Directory.FullName & "\" & objCustomerCaseResponse.EvidenceFile.Trim '-- Destination file
                        Response.Redirect("../Download.aspx?file=" & PathFile)
                    End If
                End If
            Case "Edit"
                ViewState.Add("vsProcess", "Edit")
                ViewCustomerCaseResponse(e.Item.Cells(0).Text, True)
                dgCase.SelectedIndex = e.Item.ItemIndex
                ddlStatus.Enabled = False
            Case "Delete"
                Try
                    dgCase.SelectedIndex = e.Item.ItemIndex
                    Dim objCustomerCaseResponse As CustomerCaseResponseFacade = New CustomerCaseResponseFacade(User)
                    objCustomerCaseResponse.Delete(objCustomerCaseResponse.Retrieve(CInt(e.Item.Cells(0).Text)))
                    BindDataResponse(dgCase.CurrentPageIndex)
                Catch ex As Exception
                    MessageBox.Show(SR.DeleteFail)
                End Try
            Case "ReSend"
                Dim objresponseFacade As CustomerCaseResponseFacade = New CustomerCaseResponseFacade(User)
                Dim objresponse As CustomerCaseResponse = objresponseFacade.Retrieve(CInt(e.Item.Cells(0).Text))

                Dim sf As SalesForceInterface = New SalesForceInterface()
                Dim msg As String = String.Empty
                Dim vSFreturn As Boolean = False
                vSFreturn = sf.UpdateCase(objresponse)

                Dim arr = New ArrayList
                Dim _criterias As New CriteriaComposite(New Criteria(GetType(WsLog), "RowStatus", MatchType.Exact, CType(DBRowStatus.Active, Short)))
                _criterias.opAnd(New Criteria(GetType(WsLog), "Message", MatchType.Exact, String.Empty))
                _criterias.opOr(New Criteria(GetType(WsLog), "Message", MatchType.Exact, vbNull))
                _criterias.opAnd(New Criteria(GetType(WsLog), "Source", MatchType.Exact, "Internal"))
                _criterias.opAnd(New Criteria(GetType(WsLog), "Status", MatchType.Exact, "False"))
                _criterias.opAnd(New Criteria(GetType(WsLog), "Body", MatchType.[Partial], "SALESFORCEIUPDATECASE"))
                _criterias.opAnd(New Criteria(GetType(WsLog), "Body", MatchType.[Partial], objresponse.CustomerCase.SalesforceID))
                arr = New WsLogFacade(User).Retrieve(_criterias)

                If vSFreturn Or arr.Count > 0 Then
                    'Update IsSend
                    Dim objResponseNew As CustomerCaseResponse = New CustomerCaseResponse()
                    If objresponse.ID > 0 Then
                        objResponseNew = New CustomerCaseResponseFacade(User).Retrieve(objresponse.ID)
                    End If
                    objResponseNew.IsSend = 1 'sent
                    Dim nResult As Integer = New CustomerCaseResponseFacade(User).Update(objResponseNew)
                Else
                    MessageBox.Show("Proses re-send gagal")
                End If
        End Select
    End Sub

    Private Sub dgCase_ItemDataBound(sender As Object, e As DataGridItemEventArgs) Handles dgCase.ItemDataBound
        If e.Item.ItemIndex >= 0 Then
            Dim RowValue As CustomerCaseResponse = CType(e.Item.DataItem, CustomerCaseResponse)
            Dim lblStatus As Label = CType(e.Item.FindControl("lblStatus"), Label)
            Dim lnkbtnEdit As LinkButton = CType(e.Item.FindControl("lbtnEdit"), LinkButton)
            Dim lnkbtnDownload As LinkButton = CType(e.Item.FindControl("lbtnDownload"), LinkButton)
            Dim hdnEvidenceFile As HiddenField = CType(e.Item.FindControl("hdnEvidenceFile"), HiddenField)
            Dim lnkbtnResend As LinkButton = CType(e.Item.FindControl("lbtnResend"), LinkButton)
            Dim hdnIsSend As HiddenField = CType(e.Item.FindControl("hdnIsSend"), HiddenField)

            Dim lblNo As Label = CType(e.Item.FindControl("lblNo"), Label)
            lblNo.Text = (e.Item.ItemIndex + 1) + (dgCase.CurrentPageIndex * dgCase.PageSize)
            lblStatus.Text = EnumCustomerCaseResponse.GetStringCustomerResponse(RowValue.Status)

            If hdnEvidenceFile.Value.Trim = "" Then
                lnkbtnDownload.Visible = False
            Else
                lnkbtnDownload.Visible = True
            End If
            If hdnIsSend.Value.Trim = "1" Then
                lnkbtnResend.Visible = False
            Else
                lnkbtnResend.Visible = True
            End If

            'If Not e.Item.FindControl("lbtnDelete") Is Nothing Then
            '    CType(e.Item.FindControl("lbtnDelete"), LinkButton).Attributes.Add("OnClick", "setSelected(this, '" & RowValue.ID & "');")
            'End If
        End If
    End Sub

    Private Sub lbtnDelEvidenceFile_Click(sender As Object, e As EventArgs) Handles lbtnDelEvidenceFile.Click
        LblEvidenceFile.Visible = False
        lbtnDelEvidenceFile.Visible = False
        EvidenceFile.Visible = True
        LblEvidenceFile.Text = hdnDestFile.Value
        hdnDestFile.Value = ""
    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        ddlStatus.Enabled = True
        LblEvidenceFile.Visible = False
        lbtnDelEvidenceFile.Visible = False
        EvidenceFile.Visible = True

        ddlStatus.SelectedIndex = 0
        txtComment.Text = ""
        EvidenceFile.Attributes.Clear()
        LblEvidenceFile.Text = ""
        hdnDestFile.Value = ""
        lblValidddlStatus.Text = ""
        lblValidtxtComment.Text = ""
        lblValidFile.Text = ""

        BindDataResponse(dgCase.CurrentPageIndex)
        ViewState.Add("vsProcess", "Insert")
    End Sub
End Class